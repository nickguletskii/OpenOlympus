'use strict';

define(['angular', 'services', 'lodash'], function(angular, services, _) {

    /* Directives */

    angular.module('ool.directives', ['ool.services']).directive('eatClickIf', ['$parse', '$rootScope',
        function($parse, $rootScope) {
            return {
                // this ensure eatClickIf be compiled before ngClick
                priority: 100,
                restrict: 'A',
                compile: function($element, attr) {
                    var fn = $parse(attr.eatClickIf);
                    return {
                        pre: function link(scope, element) {
                            var eventName = 'click';
                            element.on(eventName, function(event) {
                                var callback = function() {
                                    if (fn(scope, {
                                            $event: event
                                        })) {
                                        // prevents ng-click to be executed
                                        event.stopImmediatePropagation();
                                        // prevents href 
                                        event.preventDefault();
                                        return false;
                                    }
                                };
                                if ($rootScope.$$phase) {
                                    scope.$evalAsync(callback);
                                } else {
                                    scope.$apply(callback);
                                }
                            });
                        },
                        post: function() {}
                    }
                }
            }
        }
    ]).directive("oolinput", ['$compile', function($compile) {
        return {
            restrict: "A",
            link: function(scope, element, attrs, ctrl, transclude) {
                var wrapper = angular.element('<div class="form-group" />');
                var label = angular.element('<label class="control-label"></label>');
                var name = attrs.ngModel.match(/(^.*\.|^)([a-zA-Z0-9_-]+)$/)[2];
                label.attr({
                    "for": name
                }).html("{{'" + attrs.label + "' | translate}}");
                element.after(wrapper);
                element.removeAttr("oolinput");
                element.addClass("form-control");
                attrs.$set("name", name);
                wrapper.prepend(element);
                wrapper.prepend(label);
                $compile(label)(scope);
                scope.$on("$destroy", function() {
                    wrapper.after(element);
                    wrapper.remove();
                });
            }
        };
    }]).directive('ngUsername', function($q, $timeout) {
        var USERNAME_REGEXP = /^[a-zA-Z0-9_-]+$/;

        return {
            require: 'ngModel',
            restrict: 'A',
            link: function(scope, elm, attrs, ctrl) {
                ctrl.$validators.username = function(modelValue, viewValue) {
                    return USERNAME_REGEXP.test(viewValue);
                };
            }
        };
    }).directive('ngLength', function($q, $timeout) {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, elm, attrs, ctrl) {
                ctrl.$validators.length = function(modelValue, viewValue) {
                    if (!modelValue)
                        return true;

                    var tokens = attrs.ngLength.split(/,/);
                    var minLength = parseInt(tokens[0]);
                    var maxLength = parseInt(tokens[1]);
                    if (isNaN(maxLength))
                        maxLength = Number.MAX_VALUE;
                    return modelValue.length >= minLength && modelValue.length <= maxLength;
                };
            }
        };
    }).directive('ngPasswordsMatchSlave', function($q, $timeout, ServersideFormErrorReporter, ValidationService) {
        return {
            restrict: 'A',
            scope: {

            },
            require: ['ngModel', '^form'],
            link: function(scope, elem, attr, controllers) {
                var ctrl = controllers[0];
                var formCtrl = controllers[1];
                $timeout(function() {
                    ctrl.$validators.passwordsMatch = function(modelValue) {
                        return formCtrl[attr.ngPasswordsMatchSlave].$modelValue == modelValue;
                    };
                });
                ctrl.$validators.passwordsMatch = function(modelValue) {
                    return true;
                };
            }
        };
    }).directive('ngPasswordsMatchMaster', function($q, $timeout, ServersideFormErrorReporter, ValidationService) {
        return {
            restrict: 'A',
            scope: {

            },
            require: ['ngModel', '^form'],
            link: function(scope, elem, attr, controllers) {
                var ctrl = controllers[0];
                var formCtrl = controllers[1];
                scope.$watch(function() {
                    return ctrl.$viewValue;
                }, function(newValue, oldValue) {
                    if (newValue === oldValue)
                        return;
                    formCtrl[attr.ngPasswordsMatchMaster].$setViewValue("", '', true);
                    formCtrl[attr.ngPasswordsMatchMaster].$render();
                });
            }
        };
    }).directive('datepickerLocaldate', ['$parse', function($parse) {
        var directive = {
            restrict: 'A',
            require: ['ngModel'],
            link: link
        };
        return directive;

        function link(scope, element, attr, ctrls) {
            var ngModelController = ctrls[0];

            // called with a JavaScript Date object when picked from the datepicker
            ngModelController.$parsers.push(function(viewValue) {
                // undo the timezone adjustment we did during the formatting
                viewValue.setMinutes(viewValue.getMinutes() - viewValue.getTimezoneOffset());
                // we just want a local date in ISO format
                return viewValue.toISOString().substring(0, 10);
            });

            // called with a 'yyyy-mm-dd' string to format
            ngModelController.$formatters.push(function(modelValue) {
                if (!modelValue) {
                    return undefined;
                }
                // date constructor will apply timezone deviations from UTC (i.e. if locale is behind UTC 'dt' will be one day behind)
                var dt = new Date(modelValue);
                // 'undo' the timezone offset again (so we end up on the original date again)
                dt.setMinutes(dt.getMinutes() + dt.getTimezoneOffset());
                return dt;
            });
        }
    }]);
});
