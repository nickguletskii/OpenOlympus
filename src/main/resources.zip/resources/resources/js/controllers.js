'use strict';

var stateList = [{
    "name": "archiveTaskList",
    "url": "/archive/tasks?page",
    "templateUrl": "/partials/archive/tasks",
    "controllerPath": "controllers/archive/tasks",
    "controller": "ArchiveTaskListController",
    "params": {
        "page": 1
    }
}, {
    "name": "archiveRank",
    "url": "/archive/users?page",
    "templateUrl": "/partials/archive/users",
    "controllerPath": "controllers/archive/users",
    "controller": "ArchiveRankController",
    "params": {
        "page": 1
    }
}, {
    "name": "login",
    "url": "/login?failure",
    "templateUrl": "/partials/login",
    "controllerPath": "controllers/login",
    "controller": "LoginController",
    "narrow": true,
    "params": {
        "failure": false
    }
}, {
    "name": "register",
    "url": "/register",
    "templateUrl": "/partials/register",
    "controllerPath": "controllers/register",
    "controller": "RegistrationController",
    "narrow": true
}, {
    "name": "home",
    "url": "/",
    "templateUrl": "/partials/home",
    "controllerPath": "controllers/home",
    "controller": "HomeController",
    "type": "requireController",
    "narrow": true
}];

var modalStateList = [{
    "parent": "archiveTaskList",
    "name": "archiveTaskList.rejudgeTaskConfirmation",
    "templateUrl": "/partials/archive/tasks/rejudgeTask/confirmation",
    "backdrop": true
}, {
    "parent": "archiveTaskList",
    "name": "archiveTaskList.rejudgeTaskWorking",
    "templateUrl": "/partials/archive/tasks/rejudgeTask/working",
    "controllerPath": "controllers/archive/tasks/rejudgeWorker",
    "controller": "TaskRejudgementWorkerController",
    "backdrop": true
}];

var required = ['require', 'angular', 'lodash', 'services'];
stateList.forEach(function(state) {
    required.push(state.controllerPath);
});


define(required, function(require, angular, _) {

    var getControllerInjector = function(controllerPath) {
        return ['$scope', '$stateParams', '$injector',
            function($scope, $stateParams, $injector) {
                require([controllerPath], function(controller) {
                    $injector.invoke(controller, this, {
                        '$scope': $scope,
                        '$stateParams': $stateParams
                    });
                });
            }
        ];
    };

    var controllers = angular.module('ool.controllers', ['ool.services']);


    _.each(stateList, function(state) {
        controllers.controller(state.controller, getControllerInjector(state.controllerPath));
    });

    controllers.config(function($stateProvider, modalStateProvider) {

        _.each(stateList, function(state) {
            $stateProvider.state(state);
        });
        _.each(modalStateList, function(state) {
            modalStateProvider.state(state.name, state);
        });
    });

});
