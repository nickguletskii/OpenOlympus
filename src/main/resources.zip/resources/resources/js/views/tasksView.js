define([ 'oolutil', 'jquery', 'foundation', 'vue', 'rest',
		'rest/interceptor/mime', 'rest/interceptor/errorCode' ], function(Util,
		$, foundation, Vue, rest, mime, errorCode) {
	return function(apiPath, additionalParams, additionalMethods,
			additionalData) {
		var tasksController = new Vue({
			el : '#tasksView',
			data : Util.mergeObjects({
				tasks : []
			}, additionalData),
			methods : Util.mergeObjects({
				refresh : function() {
					var params = Util.getURLParameters();
					var page = ('page' in params) ? params['page'] : 1;

					client = rest.wrap(mime).wrap(errorCode, {});
					client({
						path : apiPath,
						params : Util.mergeObjects({
							"page" : page
						}, additionalParams)
					}).then(
							function(response) {
								tasksController.tasks = response.entity;
								tasksController.tasks.forEach(function(task) {
									task.timeAdded = new Date(task.timeAdded)
											.toDateString();
								});
							}, function(response) {
								console.error('response error: ', response);
							});
				}
			}, additionalMethods)
		})
		tasksController.$options.methods.refresh();
		return tasksController;
	}
});