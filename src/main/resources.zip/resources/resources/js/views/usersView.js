define([ 'oolutil', 'jquery', 'foundation', 'vue', 'rest',
		'rest/interceptor/mime', 'rest/interceptor/errorCode' ], function(Util,
		$, foundation, Vue, rest, mime, errorCode) {
	return function(apiPath, additionalParams, additionalMethods,
			additionalData) {
		var usersController = new Vue({
			el : '#userView',
			data : Util.mergeObjects({
				users : []
			}, additionalData),
			methods : Util.mergeObjects({
				refresh : function() {
					var params = Util.getURLParameters();
					var page = ('page' in params) ? params['page'] : 1;

					client = rest.wrap(mime).wrap(errorCode, {});
					client({
						path : apiPath,
						params : Util.mergeObjects({
							"page" : page
						}, additionalParams)
					}).then(function(response) {
						usersController.users = response.entity;
					}, function(response) {
						console.error('response error: ', response);
					});
				}
			}, additionalMethods)
		})
		usersController.$options.methods.refresh();
		return usersController;
	}
});