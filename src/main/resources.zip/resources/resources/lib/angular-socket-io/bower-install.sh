#!/bin/bash
bower install --force angular#$VERSION angular-mocks#$VERSION
