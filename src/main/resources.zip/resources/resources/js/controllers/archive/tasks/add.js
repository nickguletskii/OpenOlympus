define(['oolutil', 'lodash'],
    function(Util, _) {
        return function($timeout, $q, $scope, $rootScope, $http,
            $location, $stateParams, Restangular, $state, AuthenticationProvider, ServersideFormErrorReporter, ValidationService, $upload) {
            $scope.$apply(function() {
                $scope.serverErrorReporter = new ServersideFormErrorReporter();
                $scope.userForm.forceValidation = true;
                $scope.user = {};

                $scope.register = function(user) {
                    $upload.upload({
                        method: 'POST',
                        url: '/api/task/create',
                        headers: {
                            'X-Auth-Token': $rootScope.authToken
                        },
                        data: user
                    }).then(function(response) {
                        if (response.data.status === "BINDING_ERROR") {
                            ValidationService.report($scope.serverErrorReporter, $scope.userForm, response.data.fieldErrors);
                        } else {}
                    });
                };

            });
        };
    });
