'use strict';

define(['angular', 'app', 'lodash'], function(angular, app, _) {

    /* Services */

    // Demonstrate how to register services
    // In this case it is a simple value service.
    angular.module('ool.services', []).factory('AuthenticationProvider', function($rootScope, $http, $timeout) {
        var data = {
            loggedIn: false,
            username: null,
            roles: []
        };
        var poller = function() {
            $http.get('/api/security/userStatus').then(function(r) {
                data = r.data;
                $rootScope.$broadcast('securityInfoChanged');
                $timeout(poller, 60000);
            });
        };
        poller();

        var transform = function(data) {
            return $.param(data);
        };

        var update = function() {
            $http.get('/api/security/userStatus').then(function(r) {
                data = r.data;
                $rootScope.$broadcast('securityInfoChanged');
            });
        };

        return {
            data: data,
            isLoggedIn: function() {
                return data.loggedIn;
            },
            getUsername: function() {
                return data.username;
            },
            isUser: function() {
                return _.contains(data.roles, "USER");
            },
            isAdmin: function() {
                return _.contains(data.roles, "SUPERUSER");
            },
            update: update,
            login: function(username, password) {
                return $http({
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    method: 'POST',
                    url: '/login',
                    transformRequest: transform,
                    data: {
                        username: username,
                        password: password
                    }
                });
            },
            logout: function() {
                $http({
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    method: 'POST',
                    url: '/logout',
                    transformRequest: transform,
                    data: {}
                }).success(function(x) {
                    update();
                });
            }
        };
    }).factory('ServersideFormErrorReporter', function() {

        return function() {
            return {
                existingErrorKeys: {},
                report: function(ctrl, field, errors) {
                    var self = this;
                    if (!_.has(self.existingErrorKeys, field))
                        self.existingErrorKeys[field] = [];
                    _.forEach(self.existingErrorKeys[field], function(errorKey) {
                        ctrl.$setValidity(errorKey, true);
                    });
                    self.existingErrorKeys[field].length = 0;

                    if (!errors)
                        return;

                    _.forEach(errors, function(error) {
                        if (error.field === field) {
                            ctrl.$setValidity(error.defaultMessage, false);
                            self.existingErrorKeys[field].push(error.defaultMessage);
                        }
                    });

                }
            };
        };
    }).factory('ValidationService', function() {
        return {
            report: function(reporter, form, errors) {
                _.chain(form).filter(function(element) {
                    return _.has(element, "$setValidity");
                }).map(function(element) {
                    return element.$name;
                }).forEach(function(field) {
                    reporter.report(form[field], field, errors);
                });
            }
        };
    }).provider('modalState', function($stateProvider) {
        var provider = this;
        this.$get = function() {
            return provider;
        };
        this.state = function(stateName, options) {
            var modalInstance;
            $stateProvider.state(stateName, {
                url: options.url,
                onEnter: function($modal, $state) {
                    modalInstance = $modal.open(options);
                    modalInstance.result['finally'](function() {
                        modalInstance = null;
                        if ($state.$current.name === stateName) {
                            $state.go('^');
                        }
                    });
                },
                onExit: function() {
                    if (modalInstance) {
                        modalInstance.close();
                    }
                }
            });
        };
    });

});
