define(['oolutil', 'lodash'],
    function(Util, _) {
        return function($timeout, $q, $scope, $rootScope, $http,
            $location, $stateParams, Restangular, $state, AuthenticationProvider, ServersideFormErrorReporter, ValidationService) {
            $scope.$apply(function() {
                $http.get("/api/security/userStatus").success(function(response) {
                    if (response.loggedIn) {
                        $state.go("home");
                    } else {
                        $scope.logInFormVisible = true;
                    }
                });
                $scope.serverErrorReporter = new ServersideFormErrorReporter();
                $scope.userForm.forceValidation = true;
                $scope.user = {};

                $scope.register = function(user) {
                    $http({
                        method: 'POST',
                        url: '/api/user/register',
                        data: user
                    }).then(function(response) {
                        if (response.data.status === "BINDING_ERROR") {
                            ValidationService.report($scope.serverErrorReporter, $scope.userForm, response.data.fieldErrors);
                        } else {
                            $state.go("login");
                        }
                    });
                };

            });
        };
    });
