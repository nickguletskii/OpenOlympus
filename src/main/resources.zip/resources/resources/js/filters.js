'use strict';

define(['angular', 'services', 'lodash'], function(angular, services, _) {

    /* Filters */

    angular.module('ool.filters', ['ool.services'])
        .filter("asDate", function() {
            return function(input) {
                return new Date(input);
            };
        });
});
