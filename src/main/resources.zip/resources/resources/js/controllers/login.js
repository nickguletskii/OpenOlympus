define(['oolutil', 'lodash'],
    function(Util, _) {
        return function($timeout, $q, $scope, $rootScope, $http,
            $location, $stateParams, Restangular, $state, AuthenticationProvider) {
            $scope.$apply(function() {
                $http.get("/api/security/userStatus").success(function(response) {
                    if (response.loggedIn) {
                        $state.go("home");
                    } else {
                        $scope.logInFormVisible = true;
                    }
                });

                function changeTooltips(authStatus) {
                    if (authStatus == "failed") {
                        $scope.usernameTooltip = getTranslation("login.wrongUsernameOrPassword");
                        $scope.passwordTooltip = getTranslation("login.wrongUsernameOrPassword");
                    } else {
                        $scope.usernameTooltip = null;
                        $scope.passwordTooltip = null;
                    }
                }

                $scope.login = function() {

                    AuthenticationProvider.login($scope.username, $scope.password).success(function(response) {
                        if (response.auth === "succeded") {
                            AuthenticationProvider.update();
                            $state.go("home");
                        } else if (response.auth === "failed") {
                            $scope.authError = true;
                            changeTooltips(response.auth);
                        }
                    });

                };
                $scope.username = "";
                $scope.password = "";
                changeTooltips("none");
            });
        };
    });
