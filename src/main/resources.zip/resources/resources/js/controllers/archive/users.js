define(['oolutil', 'lodash'],
    function(Util, _) {
        return ['$timeout', '$q', '$scope', '$rootScope', '$http', '$location',
            '$stateParams', 'Restangular',
            function($timeout, $q, $scope, $rootScope, $http, $location,
                $stateParams, Restangular) {

                $scope.$apply(function() {
                    var page = $stateParams.page;

                    $scope.page = $stateParams.page;

                    Restangular.all('api/archive/rank').getList({
                        page: page
                    }).then(function(users) {
                        $scope.users = users;
                    });
                    $http.get('api/archive/rankCount').then(function(response) {
                        $scope.userCount = response.data;
                    });
                });
            }
        ];
    });
