# DefaultErrorListRenderer

This renderer is the default implementation of error list renderer.

Please see [this renderers source code][source] if you want to extend it or override some functionality.
Is very well documented with JSDoc.


[source]: ../../../src/errors/renderers/default.js
