define(['oolutil', 'lodash'],
    function(Util, _) {
        return ['$timeout', '$q', '$scope', '$rootScope', '$http', '$location',
            '$stateParams', 'Restangular',
            function($timeout, $q, $scope, $rootScope, $http, $location,
                $stateParams, Restangular) {
                $scope.$apply(function() {
                    
                });
            }
        ];
    });
