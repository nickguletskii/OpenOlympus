# bower-angular-translate-loader-url

angular-translate-loader-url bower package

### Installation

````
$ bower install angular-translate-loader-url
````
