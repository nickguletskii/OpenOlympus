'use strict';

define(['require', 'angular', 'bootstrap', 'filters', 'services', 'directives', 'controllers',
    'ui-route', 'restangular', 'bootstrap-tpls', 'angular-form-validation', 'angular-translate', "angular-translate-loader-url"
], function(require, angular,
    bootstrap, filters, services, directives, controllers) {
    // Declare app level module which depends on filters, and services

    var app = angular.module('ool', ['pascalprecht.translate', 'restangular', 'ui.router',
        'ui.bootstrap', 'ool.filters', 'ool.controllers',
        'ool.services', 'ool.directives', 'ngFormValidation', 'angularFileUpload'
    ]);
    app.config([
        'formValidationDecorationsProvider',
        'formValidationErrorsProvider',
        function(
            formValidationDecorationsProvider,
            formValidationErrorsProvider
        ) {
            formValidationDecorationsProvider
                .useBuiltInDecorator('bootstrap');
            formValidationErrorsProvider
                .useBuiltInErrorListRenderer('bootstrap');
        }
    ]);

    var dictionary = {
        instantTranslationFunc: {},
        getString: function(name, parameters, language) {
            return dictionary.instantTranslationFunc("validation.errors." + name);
        }
    };

    app.run(function($rootScope, $translate) {
        $rootScope.$on('$translateChangeSuccess',
            function(event, language) {
                dictionary.instantTranslationFunc = $translate.instant;
            });
    });

    app.config(['$translateProvider', 'formValidationErrorsProvider', '$injector', function($translateProvider, $formValidationErrorsProvider) {
        $translateProvider.useUrlLoader('/translation.json');
        $translateProvider.preferredLanguage('ru');
        $formValidationErrorsProvider.setDictionary(dictionary);
    }]);

    app.config(function($httpProvider, $locationProvider, $stateProvider) {

        $locationProvider.html5Mode(true);

        $httpProvider.interceptors.push(function($q, $rootScope, $location) {
            return {
                'responseError': function(rejection) {
                    var status = rejection.status;
                    var config = rejection.config;
                    var method = config.method;
                    var url = config.url;

                    if (status == 401) {
                        $location.path("/login");
                    } else {
                        $rootScope.error = method + " on " + url + " failed with status " + status;
                    }

                    return $q.reject(rejection);
                }
            };
        });

        $httpProvider.interceptors.push(function($q, $rootScope, $location) {
            return {
                'request': function(config) {
                    var isRestCall = config.url.indexOf('rest') === 0;
                    if (isRestCall && angular.isDefined($rootScope.authToken)) {
                        var authToken = $rootScope.authToken;
                        config.headers['X-Auth-Token'] = authToken;
                    }
                    return config || $q.when(config);
                }
            };
        });

    });

    return app;
});
